"""
Routes and views for the flask application.
"""

from datetime import datetime
from ssl import SSLSession
from urllib import request
from flask import render_template
from FlaskWebProject2 import app
import sqlalchemy

@app.route('/')
@app.route('/home')
def home():
    """Renders the home page."""
    return render_template(
        'index.html',
        title='Home Page',
        year=datetime.now().year,
    )

@app.route('/stworzzgloszenie')
def stworzzgloszenie():
    """Renders the stworzzgloszenie page."""
    return render_template(
        'stworzzgloszenie.html',
        title='stworzzgloszenie',
        year=datetime.now().year,
        message='Your stworzzgloszenie page.'
    )

@app.route('/kontakt')
def kontakt():
    """Renders the kontakt page."""
    return render_template(
        'kontakt.html',
        title='kontakt',
        year=datetime.now().year,
        message='Your application description page.'
    )

@app.route('/bazawiedzy')
def bazawiedzy():
    """Renders the bazawiedzy page."""
    return render_template(
        'bazawiedzy.html',
        title='bazawiedzy',
        year=datetime.now().year,
        message='Your application description page.'
    )

@app.route('/bazawiedzy/programowanie')
def programowanie():
    """Renders the dodajzgloszenie page."""
    return render_template(
        'programowanie.html',
        title='programowanie',
        year=datetime.now().year,
        message='Your application description page.'
    )

@app.route('/bazawiedzy/siecikomputerowe')
def siecikomputerowe():
    """Renders the siecikomputerowe page."""
    return render_template(
        'siecikomputerowe.html',
        title='siecikomputerowe',
        year=datetime.now().year,
        message='Your application description page.'
        )

@app.route('/bazawiedzy/bazydanych')
def bazydanych():
    """Renders the bazydanych page."""
    return render_template(
        'bazydanych.html',
        title='bazydanych',
        year=datetime.now().year,
        message='Your application description page.'
        )